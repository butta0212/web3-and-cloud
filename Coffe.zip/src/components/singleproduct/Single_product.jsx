import { Link, useLocation } from "react-router-dom";
import React, { useEffect, useState } from "react";
import AppImage05 from "../../assets/coffee (1).jpg";
import {
  prepareWriteContract,
  waitForTransaction,
  writeContract,
} from "@wagmi/core";
import { ContractAbi, ContractAddress } from "../../utils/Contract";
import toast from "react-hot-toast";
import { useAccount } from "wagmi";
import { useNavigate } from "react-router-dom";

export default function Single_product() {
  const { address } = useAccount();
  const [spinner, setspinner] = useState(false);
  const navigate = useNavigate();

  let loction = useLocation();
  loction = loction?.state;

  // console.log("loction", loction);

  const buyProduct = async (id, price) => {
    try {
      setspinner(true);
      let constPriceValue = Number(price) * 1000000000000000000;
      console.log("constPriceValue", constPriceValue);
      setspinner(true);
      const { request } = await prepareWriteContract({
        address: ContractAddress,
        abi: ContractAbi,
        functionName: "buyCoffee",
        args: ["1"],
        value: constPriceValue.toString(),
        account: address,
      });
      const { hash } = await writeContract(request);
      const data = await waitForTransaction({
        hash,
      });
      setTimeout(() => {
        setspinner(false);
        toast.success("You Buy this Product successfully");
        navigate("/");
      }, 3000);
    } catch (error) {
      console.log(error);
      setspinner(false);
    }
  };
  return (
    <div>
      <div className="px-4 sm:px-6 lg:px-8 py-8 w-full">
        {/* Page content */}
        <div className="max-w-5xl mx-auto flex flex-col lg:flex-row lg:space-x-8 xl:space-x-16">
          {/* Content */}
          <div className="w-full">
            <div className="mb-3">
              <Link
                className="text-sm font-medium text-slate-800 hover:text-indigo-600 dark:hover:text-indigo-400"
                to="/"
              >
                {" "}
                Back To Listing
              </Link>
            </div>
            <header className="mb-4">
              {/* Title */}
              <h1 className="text-2xl md:text-3xl text-slate-800 font-bold mb-2">
                {loction?.title} ✨
              </h1>
            </header>

            <div>
              <h2 className="text-xl leading-snug text-slate-800 font-bold mb-2">
                Overview
              </h2>
              <p className="mb-6">Product Details</p>
              <p>{loction?.dis}</p>
            </div>
          </div>

          {/* Sidebar */}
          <div>
            <figure className="mb-6">
              <img
                className=" rounded-sm"
                src={loction?.image}
                width="440"
                height="260"
                alt="Product"
              />
            </figure>
            <div className="bg-white dark:bg-slate-800 p-5 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700 lg:w-72 xl:w-80">
              <div className="mb-1">
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginBottom: "1rem",
                    fontSize: "1rem",
                    color: "#fff",
                  }}
                >
                  <p>Price</p>
                  <p>{loction?.price}</p>
                </div>
                <button
                  className="btn w-full bg-primarycl text-white"
                  onClick={() => buyProduct(loction?.id, loction?.price)}
                >
                  {spinner ? "Loading..." : " Buy Now"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
