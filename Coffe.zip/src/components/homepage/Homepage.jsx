/* eslint-disable react/jsx-no-undef */
import herobg from "../../assets/herobg.jpg";
import { Link } from "react-router-dom";

import AppImage05 from "../../assets/coffee (1).jpg";
import AppImage06 from "../../assets/coffee (2).jpg";
import AppImage07 from "../../assets/coffee (3).jpg";
import AppImage08 from "../../assets/coffee (4).jpg";
import { useNavigate } from "react-router-dom";
// import AppImage09 from '../../assets/coffee (5).jpg';

const productObject = [
  {
    id:"1",
    title: "Morning Bliss",
    dis: "Wake up to a smooth blend of aromatic beans, perfect for starting your day right",
    price: "0.0001",
    rank: "4.7",
    image:AppImage05
  },
  {
    id:"2",
    title: "Sunrise Roast",
    dis: "A bold and invigorating brew that welcomes every morning with robust",
    price: "0.0003",
    rank: "4.1",
    image:AppImage06
  },
  {
    id:"3",
    title: "Misty Mornings",
    dis: "Delight in the misty aroma and delicate taste of our signature morning blend",
    price: "0.0005",
    rank: "4.8",
    image:AppImage07

  },
  {
    id:"4",
    title: "Soleil Supreme",
    dis: "Bask in the radiant flavor of our premium coffee, crafted to brighten your day",
    price: "0.0002",
    rank: "3.6",
    image:AppImage08

  },
];

export default function Homepage() {
  const navigate = useNavigate();

  return (
    <div>
      <div
        className="relative min-h-[550px] flex flex-col justify-center items-start"
        style={{
          backgroundImage: `url(${herobg})`,
          backgroundRepeat: "no-repeat",
          // backgroundPosition:'cover',
          backgroundSize: "100% 100%",
        }}
      >
        <div className="px-4 md:px-10 lg:px-20 py-10 max-w-screen-lg">
          <div className="flex flex-col justify-center items-start gap-3">
            <h1 className="text-xl md:text-4xl font-bold text-white uppercase">
              Indulge in the Perfect Cup of Coffee <br />{" "}
              <span className="text-primarycl capitalize">
                Experience the Essence of Crafted Coffee
              </span>
            </h1>
            <p className="text-lg font-normal text-white">
              From rich roasts to delicate blends, every sip is an invitation to
              savor the moment
            </p>
          </div>
        </div>
      </div>
      <div className="mt-8 px-4 lg:px-10 pb-10">
        <h2 className="text-xl leading-snug text-slate-800  font-bold mb-5">
          Products
        </h2>
        <div className="grid grid-cols-12 gap-6">
          {productObject.map((items, index) => {
            return (
              <>
                <div className="col-span-full sm:col-span-6 xl:col-span-3 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
                  <div className="flex flex-col h-full">
                    {/* Image */}
                    <div className="relative">
                      <img
                        className="w-full"
                        src={items?.image}
                        width="286"
                        height="160"
                        alt="Application 05"
                      />
                      {/* Popular label */}
                    </div>
                    <div className="grow flex flex-col p-5">
                      <div className="grow">
                        <header className="mb-2">
                          <h3 className="text-lg text-slate-800 dark:text-slate-100 font-semibold mb-1">
                           {items?.title}
                          </h3>
                          <div className="text-sm text-white">
                            {
                              items?.dis
                            }
                          </div>
                        </header>
                        <div className="flex flex-wrap items-center justify-between mb-5">
                          <div className="flex items-center space-x-2 mr-2">
                            <svg
                              className="w-4 h-4 fill-current text-amber-500"
                              viewBox="0 0 16 16"
                            >
                              <path d="M10 5.934L8 0 6 5.934H0l4.89 3.954L2.968 16 8 12.223 13.032 16 11.11 9.888 16 5.934z" />
                            </svg>
                            {/* Rate */}
                            <div className="text-sm font-medium whitespace-nowrap">
                              <span className="text-white">{items?.rank}</span>
                            </div>
                          </div>
                          {/* Price */}
                          <div className="flex items-center space-x-2">
                            <div className=" mt-2 inline-flex text-sm font-medium bg-emerald-100 dark:bg-emerald-400/30 text-emerald-600 dark:text-emerald-400 rounded-full text-center px-2 py-0.5">
                              {items?.price} BNB
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* Card footer */}
                      <div>
                        {/* <Link to="/singleproduct"> */}
                          {" "}
                          <button
                            className="btn-sm w-full bg-primarycl text-white"
                            onClick={() =>
                              navigate("/singleproduct",{state:items})
                            }
                          >
                            Buy Now
                          </button>
                        {/* </Link> */}
                      </div>
                    </div>
                  </div>
                </div>
              </>
            );
          })}
        </div>
      </div>
    </div>
  );
}
